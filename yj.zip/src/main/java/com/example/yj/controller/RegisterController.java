package com.example.yj.controller;

import com.example.yj.entity.Register;
import com.example.yj.repository.RegisterRespository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class RegisterController {

    @Autowired
    private RegisterRespository registerRespository;

    @GetMapping("/")
    public String index() {
        return "index";
    }

    @GetMapping("/register")
    public String getRegister() {
        return "register";
    }

    @PostMapping("/register")
    public void postRegister(@ModelAttribute Register reg) {
        registerRespository.save(reg);
    }


    @GetMapping("/article")
    public String article() {
        return "register";
    }


}
