package com.example.yj.repository;

import com.example.yj.entity.Register;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface RegisterRespository extends JpaRepository<Register, Integer> {

}
