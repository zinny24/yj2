drop database yj;

create database yj;

use yj;

CREATE TABLE register (
    num INT AUTO_INCREMENT PRIMARY KEY,
    userid VARCHAR(50) NOT NULL,
    userpw VARCHAR(100) NOT NULL,
    regdate datetime
);