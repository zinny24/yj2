package com.example.yj;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class YjApplicationTests {

	@Test
	void contextLoads() {
	}

}
